<div>
    <div>
        <?php echo e($this->table); ?>

    </div>
</div>
<?php /**PATH C:\xampp\htdocs\SIDELINE PROJECTS\BarangayGate\resources\views/livewire/admin/certificate-list.blade.php ENDPATH**/ ?>