<div>
    <header class="py-2">
        <span class="font-semibold text-blue-700 text-xl">Request Certificates</span>
    </header>
    <div>
        <?php echo e($this->table); ?>

    </div>
</div>
<?php /**PATH C:\xampp\htdocs\SIDELINE PROJECTS\BarangayGate\resources\views/livewire/resident/request-certificate.blade.php ENDPATH**/ ?>