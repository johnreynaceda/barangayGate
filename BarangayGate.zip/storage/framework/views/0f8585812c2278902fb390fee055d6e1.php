<button wire:loading.attr="disabled" wire:loading.class="!cursor-wait" wire:target="submitForm" type="button" class="outline-none inline-flex justify-center items-center group transition-all ease-in duration-150 focus:ring-2 focus:ring-offset-2 hover:shadow-sm disabled:opacity-80 disabled:cursor-not-allowed rounded gap-x-2 text-sm px-4 py-2     ring-blue-500 text-white bg-blue-500 hover:bg-blue-600 hover:ring-blue-600
    dark:ring-offset-slate-800 dark:bg-blue-700 dark:ring-blue-700
    dark:hover:bg-blue-600 dark:hover:ring-blue-600 font-medium" wire:click="submitForm">
            <svg class="w-4 h-4 shrink-0" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-3m-1 4l-3 3m0 0l-3-3m3 3V4" />
</svg>
    
    Submit

    
            <svg class="animate-spin w-4 h-4 shrink-0"
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 24 24"
                            wire:target="submitForm"
                        wire:loading.delay>
            <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
            <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
        </svg>
    </button>
<?php /**PATH C:\xampp\htdocs\SIDELINE PROJECTS\BarangayGate\storage\framework\views/a8e3afe60c4ed61f6f4661d81e7e0334.blade.php ENDPATH**/ ?>