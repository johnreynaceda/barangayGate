@section('title', 'BRGY. OFFICIALS')
<x-admin-layout>
    <div class="bg-white p-6 rounded-xl">
        <livewire:admin.official-list />
    </div>
</x-admin-layout>
