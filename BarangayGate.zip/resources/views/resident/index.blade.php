<x-resident-layout>
    <div class="bg-white  p-5 shadow rounded-xl">
        <livewire:resident.request-certificate />
    </div>
</x-resident-layout>
