<div>
    <header class="py-2">
        <span class="font-semibold text-blue-700 text-xl">Request Certificates</span>
    </header>
    <div>
        {{ $this->table }}
    </div>
</div>
