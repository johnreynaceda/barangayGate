<x-resident-layout>
    <div class="bg-white  p-5 shadow rounded-xl">
        <livewire:resident-form />
    </div>
</x-resident-layout>
