@section('title', 'BLOTTER')
<x-admin-layout>
    <div class="bg-white p-6 rounded-xl">
        <livewire:admin.blotter-list />
    </div>
</x-admin-layout>
