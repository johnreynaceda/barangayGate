@section('title', 'RESIDENTS')
<x-admin-layout>
    <div class="bg-white p-6 rounded-xl">
        <livewire:admin.resident-list />
    </div>
</x-admin-layout>
