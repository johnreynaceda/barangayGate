<?php return array (
  'admin.blotter-list' => 'App\\Http\\Livewire\\Admin\\BlotterList',
  'admin.certificate-list' => 'App\\Http\\Livewire\\Admin\\CertificateList',
  'admin.dashboard' => 'App\\Http\\Livewire\\Admin\\Dashboard',
  'admin.official-list' => 'App\\Http\\Livewire\\Admin\\OfficialList',
  'admin.resident-list' => 'App\\Http\\Livewire\\Admin\\ResidentList',
  'resident-form' => 'App\\Http\\Livewire\\ResidentForm',
  'resident.request-certificate' => 'App\\Http\\Livewire\\Resident\\RequestCertificate',
);